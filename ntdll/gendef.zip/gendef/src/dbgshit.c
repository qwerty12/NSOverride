#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN
#include <Windows.h>
#include <DbgHelp.h>
#include "dbgshit.h"
#include <string.h>
#include <stdio.h>

static HANDLE hProcessIfdbgHelpInited = NULL;

void init_dbghelp()
{
	if (hProcessIfdbgHelpInited == NULL) {
		hProcessIfdbgHelpInited = GetCurrentProcess();
		SymSetOptions(SYMOPT_UNDNAME | SYMOPT_DEFERRED_LOADS);

		if (!SymInitialize(hProcessIfdbgHelpInited, NULL, FALSE)) {
			hProcessIfdbgHelpInited = NULL;
		}
	}
}

void deinit_dbghelp()
{
	if (hProcessIfdbgHelpInited != NULL) {
		SymCleanup(hProcessIfdbgHelpInited);
		hProcessIfdbgHelpInited = NULL;
	}
}

int getNameForAddress(const char *dllPath, size_t funcAddress, const char **symName)
{
	BOOL ret = FALSE;
	CHAR szSymbolName[MAX_SYM_NAME] = { 0 };
	CHAR szImageName[MAX_PATH];
	DWORD64 dwBaseAddr = 0;

	if (hProcessIfdbgHelpInited == NULL || !dllPath || !symName)
		return ret;

	if (strlen(dllPath) > ARRAYSIZE(szImageName))
		return ret;

	strncpy(szImageName, dllPath, ARRAYSIZE(szImageName));
	szImageName[ARRAYSIZE(szImageName) - 1] = '\0';

	if ((dwBaseAddr = SymLoadModuleEx(hProcessIfdbgHelpInited,    // target process 
		NULL,        // handle to image - not used
		szImageName, // name of image file
		NULL,        // name of module - not required
		dwBaseAddr,  // base address - not required
		0,           // size of image - not required
		NULL,        // MODLOAD_DATA used for special cases 
		0)))          // flags - not required
	{
		DWORD64 dwAddress = dwBaseAddr + funcAddress;

		char buffer[sizeof(SYMBOL_INFO) + MAX_SYM_NAME * sizeof(CHAR)];
		PSYMBOL_INFO pSymbol = (PSYMBOL_INFO)buffer;

		pSymbol->SizeOfStruct = sizeof(SYMBOL_INFO);
		pSymbol->MaxNameLen = MAX_SYM_NAME;

		if (SymFromAddr(hProcessIfdbgHelpInited, dwAddress, NULL, pSymbol)) {
			strncpy(szSymbolName, pSymbol->Name, ARRAYSIZE(szSymbolName));
			szSymbolName[ARRAYSIZE(szSymbolName) - 1] = '\0';
			*symName = szSymbolName;

			ret = TRUE;
		}

		SymUnloadModule64(hProcessIfdbgHelpInited, dwBaseAddr);
	}

	return ret;
}