#pragma once

void init_dbghelp();
void deinit_dbghelp();
int getNameForAddress(const char *dllPath, size_t funcAddress, const char **symName);
