#ifndef TESTS_H
#define TESTS_H

#include <ph.h>

VOID Test_basesup(
    VOID
    );

VOID Test_format(
    VOID
    );

VOID Test_support(
    VOID
    );

#endif
