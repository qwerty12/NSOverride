//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NetAdapters.rc
//
#define IDD_NETADAPTER_OPTIONS          112
#define IDD_NETADAPTER_DIALOG           113
#define IDC_GRAPH_LAYOUT                114
#define IDD_NETADAPTER_PANEL            115
#define IDC_NETADAPTERS_LISTVIEW        1023
#define IDC_LINK_SPEED                  1026
#define IDC_ADAPTERNAME                 1026
#define IDC_LAYOUT                      1027
#define IDC_LINK_STATE                  1027
#define IDC_STAT_BSENT                  1028
#define IDC_STAT_BRECIEVED              1029
#define IDC_STAT_BTOTAL                 1030
#define IDC_DETAILS_BUTTON              1031

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
