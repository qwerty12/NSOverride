//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DotNetTools.rc
//
#define IDD_PROCDOTNETPERF              101
#define ID_COPY                         101
#define IDD_PROCDOTNETASM               102
#define IDC_APPDOMAINS                  1001
#define IDC_CATEGORIES                  1002
#define IDC_COUNTERS                    1003
#define IDC_ERROR                       1004
#define IDC_LIST                        1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
