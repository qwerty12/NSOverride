//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WindowExplorer.rc
//
#define IDD_WNDPROPS                    9
#define IDD_WNDLIST                     101
#define ID_VIEW_WINDOWS                 101
#define ID_THREAD_WINDOWS               102
#define ID_PROCESS_WINDOWS              103
#define IDR_WINDOW                      103
#define ID_SHOWCONTEXTMENU              104
#define IDD_WNDGENERAL                  104
#define ID_VIEW_DESKTOPWINDOWS          105
#define IDD_WNDSTYLES                   105
#define IDD_WNDCLASS                    106
#define IDD_WNDGENERAL1                 106
#define IDC_LIST                        1001
#define IDC_REFRESH                     1002
#define IDC_TEXT                        1009
#define IDC_RECTANGLE                   1010
#define IDC_NORMALRECTANGLE             1011
#define IDC_CLIENTRECTANGLE             1012
#define IDC_THREAD                      1016
#define IDC_STYLESLIST                  1017
#define IDC_STYLES                      1018
#define IDC_EXTENDEDSTYLES              1019
#define IDC_EXTENDEDSTYLESLIST          1020
#define IDC_INSTANCEHANDLE              1021
#define IDC_MENUHANDLE                  1022
#define IDC_WINDOWPROC                  1023
#define IDC_WINDOWPROC2                 1024
#define IDC_DIALOGPROC                  1024
#define IDC_USERDATA                    1025
#define IDC_NAME                        1026
#define IDC_ATOM                        1028
#define IDC_CURSORHANDLE                1029
#define IDC_ICONHANDLE                  1030
#define IDC_ICONHANDLE2                 1031
#define IDC_SMALLICONHANDLE             1031
#define IDC_BACKGROUNDBRUSH             1032
#define IDC_MENUNAME                    1033
#define IDC_UNICODE                     1034
#define ID_WINDOW_GOTOTHREAD            40001
#define ID_WINDOW_COPY                  40002
#define ID_WINDOW_PROPERTIES            40003
#define ID_WINDOW_BRINGTOFRONT          40004
#define ID_WINDOW_RESTORE               40005
#define ID_WINDOW_MINIMIZE              40006
#define ID_WINDOW_MAXIMIZE              40007
#define ID_WINDOW_CLOSE                 40008
#define ID_WINDOW_SHOW                  40009
#define ID_WINDOW_HIGHLIGHT             40010
#define ID_WINDOW_SHOWHIDE              40011
#define ID_WINDOW_ENABLE                40012
#define ID_WINDOW_ENABLEDISABLE         40013
#define ID_WINDOW_ALWAYSONTOP           40014
#define ID_WINDOW_OPACITY               40015
#define ID_OPACITY_10                   40016
#define ID_OPACITY_20                   40017
#define ID_OPACITY_30                   40018
#define ID_OPACITY_40                   40019
#define ID_OPACITY_50                   40020
#define ID_OPACITY_60                   40021
#define ID_OPACITY_70                   40022
#define ID_OPACITY_80                   40023
#define ID_OPACITY_90                   40024
#define ID_OPACITY_OPAQUE               40025
#define ID_WINDOW_VISIBLE               40026
#define ID_WINDOW_ENABLED               40027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40028
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
