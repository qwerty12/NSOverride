//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NetworkTools.rc
//
#define IDD_OUTPUT                      101
#define IDD_PINGDIALOG                  102
#define IDD_OPTIONS                     103
#define IDC_MAXTIMEOUTTEXT              1008
#define IDC_NETOUTPUTEDIT               1009
#define IDC_ICMP_PANEL                  1011
#define IDC_PINGS_LOST                  1012
#define IDC_ICMP_MIN                    1013
#define IDC_ICMP_MAX                    1014
#define IDC_ICMP_AVG                    1015
#define IDC_MAINTEXT                    1016
#define IDC_ANON_ADDR                   1017
#define IDC_MORE_INFO                   1019
#define IDC_PINGS_SENT                  1020
#define IDC_PING_LAYOUT                 1021
#define IDC_BAD_HASH                    1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
