//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ExtendedTools.rc
//
#define ID_PROCESS_UNLOADEDMODULES      101
#define IDD_UNLOADEDDLLS                102
#define IDD_OBJALPCPORT                 103
#define ID_THREAD_CANCELIO              104
#define IDD_OBJTPWORKERFACTORY          105
#define ID_MODULE_SERVICES              106
#define IDD_MODSERVICES                 107
#define ID_VIEW_MEMORYLISTS             108
#define IDD_PROCDISKNET                 110
#define ID_VIEW_DISKANDNETWORK          111
#define ID_PROCESS_WSWATCH              112
#define IDD_SYSINFO_DISKPANEL           113
#define IDD_OPTIONS                     114
#define IDD_WSWATCH                     115
#define IDR_EMPTYMEMLISTS               116
#define IDD_SYSINFO_GPU                 117
#define IDR_DISK                        118
#define ID_VIEW_GPUINFORMATION          119
#define IDD_SYSINFO_GPUPANEL            120
#define IDD_PROCGPU                     121
#define IDD_SYSINFO_DISK                122
#define IDD_GPUNODES                    123
#define IDD_SYSINFO_NETPANEL            124
#define IDD_SYSINFO_NET                 125
#define IDD_PROCGPU_PANEL               126
#define IDD_DISKTABRESTART              127
#define IDD_DISKTABERROR                128
#define IDD_PROCDISKNET_PANEL           129
#define IDC_LIST                        1001
#define IDC_REFRESH                     1002
#define IDC_SEQUENCENUMBER              1003
#define IDC_PORTCONTEXT                 1004
#define IDC_WORKERTHREADSTART           1005
#define IDC_WORKERTHREADCONTEXT         1006
#define IDC_SERVICES_LAYOUT             1007
#define IDC_MESSAGE                     1008
#define IDC_ZREADS_V                    1023
#define IDC_ZREADBYTES_V                1024
#define IDC_ZREADBYTESDELTA_V           1025
#define IDC_ZWRITES_V                   1026
#define IDC_ZWRITEBYTES_V               1027
#define IDC_ZWRITEBYTESDELTA_V          1028
#define IDC_ZRECEIVES_V                 1029
#define IDC_ZRECEIVEBYTES_V             1030
#define IDC_ZRECEIVEBYTESDELTA_V        1031
#define IDC_ZSENDS_V                    1032
#define IDC_ZSENDBYTES_V                1033
#define IDC_ZSENDBYTESDELTA_V           1034
#define IDC_ENABLEETWMONITOR            1035
#define IDC_ENABLE                      1036
#define IDC_WSWATCHENABLED              1037
#define IDC_NODES                       1048
#define IDC_ENABLEGPUMONITOR            1049
#define IDC_EXAMPLE                     1050
#define IDC_GROUPGPU                    1051
#define IDC_GROUPMEM                    1052
#define IDC_GROUPSHARED                 1053
#define IDC_GROUPDEDICATED              1054
#define IDC_ZDEDICATEDCURRENT_V         1055
#define IDC_ZDEDICATEDLIMIT_V           1056
#define IDC_ZSHAREDCURRENT_V            1057
#define IDC_ZSHAREDLIMIT_V              1058
#define IDC_ZDEDICATEDCOMMITTED_V       1059
#define IDC_ZRUNNINGTIME_V              1060
#define IDC_ZCONTEXTSWITCHES_V          1061
#define IDC_ZTOTALNODES_V               1062
#define IDC_ZCACHEDALLOCATED_V          1063
#define IDC_ZCACHEDRESERVED_V           1064
#define IDC_ZSHAREDCOMMITTED_V          1065
#define IDC_ZTOTALALLOCATED_V           1066
#define IDC_ZTOTALRESERVED_V            1067
#define IDC_ZWRITECOMBINEDALLOCATED_V   1068
#define IDC_ZWRITECOMBINEDRESERVED_V    1069
#define IDC_ZSECTIONALLOCATED_V         1070
#define IDC_ZSECTIONRESERVED_V          1071
#define IDC_ZTOTALSEGMENTS_V            1072
#define IDC_TITLE                       1073
#define IDC_GRAPH_LAYOUT                1074
#define IDC_LAYOUT                      1075
#define IDC_GPUNAME                     1076
#define IDC_GPU_L                       1077
#define IDC_DEDICATED_L                 1078
#define IDC_SHARED_L                    1079
#define IDC_ZRECEIVESDELTA_V            1080
#define IDC_ZSENDSDELTA_V               1081
#define IDC_ZWRITESDELTA_V              1082
#define IDC_ZREADSDELTA_V               1083
#define IDC_INSTRUCTION                 1084
#define IDC_PANEL_LAYOUT                1085
#define IDC_RESTART                     1086
#define IDC_ERROR                       1087
#define IDC_GROUPDISK                   1088
#define IDC_GROUPNETWORK                1089
#define ID_EMPTY_EMPTYWORKINGSETS       40001
#define ID_EMPTY_EMPTYMODIFIEDPAGELIST  40002
#define ID_EMPTY_EMPTYSTANDBYLIST       40003
#define ID_EMPTY_EMPTYPRIORITY0STANDBYLIST 40004
#define ID_DISK_GOTOPROCESS             40005
#define ID_DISK_COPY                    40006
#define ID_DISK_PROPERTIES              40007
#define ID_DISK_OPENFILELOCATION        40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1090
#define _APS_NEXT_SYMED_VALUE           130
#endif
#endif
