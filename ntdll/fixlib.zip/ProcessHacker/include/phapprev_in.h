#ifndef PHAPPREV_H
#define PHAPPREV_H

#define PHAPP_VERSION_REVISION $WCREV$

#endif // PHAPPREV_H
